console.warn('Importing emoji-picker-element from "emoji-picker-element/svelte" is deprecated. ' +
	'Instead, import from "emoji-picker-element" or "emoji-picker-element/picker".')
import picker from './picker.js'
export default picker