// Simple interaction or dynamic content can be added here
document.querySelector('.edit-profile-btn button').addEventListener('click', function() {
    alert("Edit Profile clicked!");
  });
  